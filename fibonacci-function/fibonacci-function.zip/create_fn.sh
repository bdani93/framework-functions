#!/bin/bash
rm fibonacci-function.zip 
zip  fibonacci-function.zip *
fission fn delete -name fibonacci-function
fission fn create --name fibonacci-function --env python --code fibonacci-function.zip --entrypoint main.main


