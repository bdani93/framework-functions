from flask import request
import fibonacci

def main():
    n = int(request.args.get('num'))
    ered = fibonacci.Fibonacci(n)
    return ered
